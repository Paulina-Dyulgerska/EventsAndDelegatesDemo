﻿namespace Problem02
{
    public interface ICanBeKilled
    {
        void Die();
    }
}
