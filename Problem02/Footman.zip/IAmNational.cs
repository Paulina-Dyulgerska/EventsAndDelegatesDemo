﻿namespace Problem02
{
    public interface IAmNational
    {
        public string Name { get; set; }

        void ResponseToAttack();
    }
}
