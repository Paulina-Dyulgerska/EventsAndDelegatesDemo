﻿namespace Problem04.IO
{
    public interface IReader
    {
        string Read();
    }
}
