﻿namespace Problem04.IO
{
    public interface IWriter
    {
        void Write(string line);
    }
}
