﻿using System;

namespace Problem05
{
    public class King : IAmNational
    {
        public event EventHandler<KingAttackedEventArgs> OnKingAttacked;

        public King(string name)
        {
            this.Name = name;
        }

        public string Name { get; set; }

        public void ResponseToAttack()
        {
            Console.WriteLine(this.ToString());
            this.OnKingAttacked?.Invoke(this, new KingAttackedEventArgs(this.Name, this.ToString()));
        }

        public override string ToString()
        {
            return $"King {this.Name} is under attack!";
        }
    }
}
