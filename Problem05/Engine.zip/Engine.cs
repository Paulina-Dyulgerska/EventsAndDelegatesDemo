﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem05
{
    public class Engine
    {
        private readonly ICollection<ICanFight> solders = new List<ICanFight>();
        private King king;

        public void Run()
        {
            var kingName = Console.ReadLine();
            var royalGuardsNames = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
            var footmansNames = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);

            this.king = new King(kingName);

            foreach (var name in royalGuardsNames)
            {
                var royalGuard = new RoyalGuard(name);
                royalGuard.OnSolderKilled += OnSolderKilledHandler;
                solders.Add(royalGuard);
            }

            foreach (var name in footmansNames)
            {
                var footman = new Footman(name);
                footman.OnSolderKilled += OnSolderKilledHandler;
                solders.Add(footman);
            }

            foreach (var solder in solders)
            {
                king.OnKingAttacked += solder.ResponseToAttack;
            }


            var input = Console.ReadLine();

            while (input != "End")
            {
                if (input == "Attack King")
                {
                    king.ResponseToAttack();
                }
                else
                {
                    var nameOfTheKilledPerson = input.Split(" ")[1];
                    var killedPerson = solders.FirstOrDefault(x => x.Name == nameOfTheKilledPerson);
                    killedPerson.Die();
                }

                input = Console.ReadLine();
            }
        }
        private void OnSolderKilledHandler(object sender, SolderEventArgs e)
        {
            this.solders.Remove((Solder)sender);
            king.OnKingAttacked -= ((Solder)sender).ResponseToAttack;
        }
    }
}
