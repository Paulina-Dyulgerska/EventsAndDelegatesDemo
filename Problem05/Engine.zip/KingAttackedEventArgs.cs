﻿using System;

namespace Problem05
{
    public class KingAttackedEventArgs : EventArgs
    {
        public KingAttackedEventArgs(string name, string kingToStringMessage)
        {
            this.Name = name;
            this.KingToStringMessage = kingToStringMessage;
        }

        public string Name { get; }

        public string KingToStringMessage { get; }
    }
}
