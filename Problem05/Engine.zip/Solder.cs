﻿using System;

namespace Problem05
{
    public abstract class Solder : ICanFight, IAmNational
    {
        private int countKillCommands;
        private readonly int killCommandsCountNeededToDie;

        public event EventHandler<SolderEventArgs> OnSolderKilled;

        public Solder(string name, int killCommandsCountNeededToDie)
        {
            this.Name = name;
            this.killCommandsCountNeededToDie = killCommandsCountNeededToDie;
        }

        public string Name { get; }

        public bool IsDead { get; private set; }

        public void Die()
        {
            this.countKillCommands++;
            if (this.countKillCommands >= this.killCommandsCountNeededToDie)
            {
                this.IsDead = true;
                this.OnSolderKilled?.Invoke(this, new SolderEventArgs(this.Name, this.ToString()));
            }
        }

        public void ResponseToAttack(object sender, KingAttackedEventArgs args)
        {
            Console.WriteLine(this.ToString());
        }
    }
}
