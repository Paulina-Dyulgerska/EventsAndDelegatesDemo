﻿namespace Problem05
{
    public interface ICanFight : IAmNational
    {
        bool IsDead { get; }

        void Die();

        void ResponseToAttack(object sender, KingAttackedEventArgs args);
    }
}
