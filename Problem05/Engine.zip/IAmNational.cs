﻿namespace Problem05
{
    public interface IAmNational
    {
        public string Name { get; }
    }
}
