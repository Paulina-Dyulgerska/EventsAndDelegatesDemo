﻿namespace ExerciseDemo.P03_DependencyInversion
{
    public interface IStrategy
    {
        double Calculate(int firstOperand, int secondOperand);
    }
}
