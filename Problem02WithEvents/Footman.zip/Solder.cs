﻿namespace Problem02WithEvents
{
    public abstract class Solder : Person
    {
        public Solder(string name) : base(name)
        {
        }

        public bool IsDied { get; set; }
        public void Die()
        {
            this.IsDied = true;
        }

        public abstract void ResponseToAttack(object sender, KingAttackedEventArgs args);
    }
}
