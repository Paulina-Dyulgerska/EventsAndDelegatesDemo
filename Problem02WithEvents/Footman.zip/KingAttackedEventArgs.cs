﻿using System;

namespace Problem02WithEvents
{
    public class KingAttackedEventArgs : EventArgs
    {

    }
}
